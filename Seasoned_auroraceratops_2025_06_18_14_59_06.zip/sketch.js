// --- Variáveis Globais ---
let jogador;
let verduras = [];
let pontuacao = 0;
let gameOver = false;

// --- Configuração Inicial ---
function setup() {
  createCanvas(800, 600); // Define o tamanho da tela
  jogador = new Jogador(); // Cria o jogador
}

// --- Loop Principal do Jogo ---
function draw() {
  background(220); // Cor de fundo (cinza claro)

  if (!gameOver) {
    // Atualiza e exibe o jogador
    jogador.mover();
    jogador.exibir();

    // Gera novas verduras em intervalos
    if (frameCount % 60 === 0) { // A cada 60 frames (aprox. 1 segundo)
      verduras.push(new Verdura());
    }

    // Atualiza e exibe as verduras
    for (let i = verduras.length - 1; i >= 0; i--) {
      verduras[i].mover();
      verduras[i].exibir();

      // Verifica colisão com o jogador
      if (dist(jogador.x, jogador.y, verduras[i].x, verduras[i].y) < jogador.tamanho / 2 + verduras[i].tamanho / 2) {
        gameOver = true; // Fim de jogo se houver colisão
      }

      // Remove verduras que saíram da tela
      if (verduras[i].y > height + verduras[i].tamanho) {
        verduras.splice(i, 1);
        pontuacao++; // Aumenta a pontuação ao desviar
      }
    }

    // Exibe a pontuação
    fill(0);
    textSize(24);
    text('Pontuação: ' + pontuacao, 10, 30);

  } else {
    // Tela de Game Over
    fill(255, 0, 0); // Vermelho
    textSize(48);
    textAlign(CENTER, CENTER);
    text('GAME OVER', width / 2, height / 2 - 30);
    textSize(24);
    text('Sua pontuação final: ' + pontuacao, width / 2, height / 2 + 20);
    textSize(20);
    text('Pressione R para Reiniciar', width / 2, height / 2 + 60);
  }
}

// --- Classe Jogador ---
class Jogador {
  constructor() {
    this.tamanho = 40;
    this.x = width / 2;
    this.y = height - 60;
    this.velocidade = 5;
  }

  exibir() {
    fill(0, 0, 255); // Azul
    rectMode(CENTER);
    rect(this.x, this.y, this.tamanho, this.tamanho);
  }

  mover() {
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= this.velocidade;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      this.x += this.velocidade;
    }
    // Limita o jogador dentro da tela
    this.x = constrain(this.x, this.tamanho / 2, width - this.tamanho / 2);
  }
}

// --- Classe Verdura ---
class Verdura {
  constructor() {
    this.tamanho = random(50, 100); // Tamanho variável
    this.x = random(width); // Posição X aleatória
    this.y = -this.tamanho; // Começa acima da tela
    this.velocidade = random(2, 5); // Velocidade de queda variável
    this.cor = color(random(0, 255), random(0, 255), random(0, 255)); // Cor aleatória para simular verduras diferentes
  }

  exibir() {
    fill(this.cor);
    // Podemos desenhar formas diferentes para as verduras
    // Por simplicidade, vou usar um círculo para todas agora
    ellipse(this.x, this.y, this.tamanho, this.tamanho);
  }

  mover() {
    this.y += this.velocidade;
  }
}

// --- Reiniciar o Jogo ---
function keyPressed() {
  if (keyCode === 82 && gameOver) { // 'R' para reiniciar
    reiniciarJogo();
  }
}

function reiniciarJogo() {
  pontuacao = 0;
  verduras = [];
  gameOver = false;
  jogador = new Jogador(); // Recria o jogador para resetar a posição
}